<template>
  <div class="overflow-hidden rounded-3xl border-[10px] border-white transition-all ease-in hover:border-[#CCE3DE] hover:bg-[#CCE3DE]">
    <div class="relative flex items-center justify-center rounded-3xl bg-[#F1F4FA] p-9 ">
      <img src="/assets/img/item.png" class="size-[182px]" alt="Item">
      <span class="py2.5 absolute left-5 top-5 rounded-md bg-[#4A5759] px-1 text-xs text-[#FFDCCD]">-20%</span>
      <span class="py2.5 absolute left-5 top-10 rounded-md bg-primary px-1 text-xs text-[#4A5759]">+30 Б</span>
      <Heart class="absolute right-5 top-5 stroke-[#4A5759]" />
    </div>
    <div class="flex flex-col gap-2">
      <p class="font-semibold">
        Краситель гелевый MIXIE Бирюзовый 20 гр
      </p>
      <span class="text-[10px] text-[#8CA9AE]">На складе 200 шт.</span>
      <span class="text-[#809A9E]">12.00 с..</span>
    </div>
  </div>
</template>
