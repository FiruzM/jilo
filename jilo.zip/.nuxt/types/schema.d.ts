import { NuxtModule, RuntimeConfig } from 'nuxt/schema'
declare module 'nuxt/schema' {
  interface NuxtConfig {
    ["vueuse"]?: typeof import("@vueuse/nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["pinia"]?: typeof import("@pinia/nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["tailwindcss"]?: typeof import("@nuxtjs/tailwindcss").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["shadcn"]?: typeof import("shadcn-nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["vueQuery"]?: typeof import("@hebilicious/vue-query-nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["autoAnimate"]?: typeof import("@formkit/auto-animate/nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["googleFonts"]?: typeof import("@nuxtjs/google-fonts").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["dayjs"]?: typeof import("dayjs-nuxt").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["i18n"]?: typeof import("@nuxtjs/i18n").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["site"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-site-config@2.2.11_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_postcss@8.4_ttmvesrazz2tqyy2pkzxa44lli/node_modules/nuxt-site-config/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["robots"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-simple-robots@4.0.0-rc.14_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_post_jnr7icndz6yp55ua4glewbbvli/node_modules/nuxt-simple-robots/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["sitemap"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/@nuxtjs+sitemap@5.1.1_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_h3@1.10.0_nuxt@3.9.1_pos_tqaiaai5nbbffgemdlwu67r5sa/node_modules/@nuxtjs/sitemap/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["ogImage"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-og-image@3.0.0-rc.42_@lezer+common@1.2.1_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10__or3ptlvifnxpa4ci3scjcqdcjm/node_modules/nuxt-og-image/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["schemaOrg"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-schema-org@3.3.4_@nuxt+devtools@1.0.8_@unhead+shared@1.8.11_@vue+compiler-core@3.4.10_nu_tsimnvqlsdznr7iru7kdswpjee/node_modules/nuxt-schema-org/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["seoExperiments"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-seo-experiments@4.0.0-rc.4_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_pos_ldebm2a3cwcog7e3465jtqk5ky/node_modules/nuxt-seo-experiments/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["linkChecker"]?: typeof import("C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-link-checker@3.0.0-rc.7_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_postcs_phtykdyapcyujaxaa4wqkkr42e/node_modules/nuxt-link-checker/dist/module").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["seo"]?: typeof import("@nuxtjs/seo").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["devtools"]?: typeof import("@nuxt/devtools").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    ["telemetry"]?: typeof import("@nuxt/telemetry").default extends NuxtModule<infer O> ? Partial<O> : Record<string, any>
    modules?: (undefined | null | false | NuxtModule | string | [NuxtModule | string, Record<string, any>] | ["@vueuse/nuxt", Exclude<NuxtConfig["vueuse"], boolean>] | ["@pinia/nuxt", Exclude<NuxtConfig["pinia"], boolean>] | ["@nuxtjs/tailwindcss", Exclude<NuxtConfig["tailwindcss"], boolean>] | ["shadcn-nuxt", Exclude<NuxtConfig["shadcn"], boolean>] | ["@hebilicious/vue-query-nuxt", Exclude<NuxtConfig["vueQuery"], boolean>] | ["@formkit/auto-animate/nuxt", Exclude<NuxtConfig["autoAnimate"], boolean>] | ["@nuxtjs/google-fonts", Exclude<NuxtConfig["googleFonts"], boolean>] | ["dayjs-nuxt", Exclude<NuxtConfig["dayjs"], boolean>] | ["@nuxtjs/i18n", Exclude<NuxtConfig["i18n"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-site-config@2.2.11_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_postcss@8.4_ttmvesrazz2tqyy2pkzxa44lli/node_modules/nuxt-site-config/dist/module", Exclude<NuxtConfig["site"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-simple-robots@4.0.0-rc.14_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_post_jnr7icndz6yp55ua4glewbbvli/node_modules/nuxt-simple-robots/dist/module", Exclude<NuxtConfig["robots"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/@nuxtjs+sitemap@5.1.1_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_h3@1.10.0_nuxt@3.9.1_pos_tqaiaai5nbbffgemdlwu67r5sa/node_modules/@nuxtjs/sitemap/dist/module", Exclude<NuxtConfig["sitemap"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-og-image@3.0.0-rc.42_@lezer+common@1.2.1_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10__or3ptlvifnxpa4ci3scjcqdcjm/node_modules/nuxt-og-image/dist/module", Exclude<NuxtConfig["ogImage"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-schema-org@3.3.4_@nuxt+devtools@1.0.8_@unhead+shared@1.8.11_@vue+compiler-core@3.4.10_nu_tsimnvqlsdznr7iru7kdswpjee/node_modules/nuxt-schema-org/dist/module", Exclude<NuxtConfig["schemaOrg"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-seo-experiments@4.0.0-rc.4_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_pos_ldebm2a3cwcog7e3465jtqk5ky/node_modules/nuxt-seo-experiments/dist/module", Exclude<NuxtConfig["seoExperiments"], boolean>] | ["C:/Users/Mad/Desktop/jilo/node_modules/.pnpm/nuxt-link-checker@3.0.0-rc.7_@nuxt+devtools@1.0.8_@vue+compiler-core@3.4.10_nuxt@3.9.1_postcs_phtykdyapcyujaxaa4wqkkr42e/node_modules/nuxt-link-checker/dist/module", Exclude<NuxtConfig["linkChecker"], boolean>] | ["@nuxtjs/seo", Exclude<NuxtConfig["seo"], boolean>] | ["@nuxt/devtools", Exclude<NuxtConfig["devtools"], boolean>] | ["@nuxt/telemetry", Exclude<NuxtConfig["telemetry"], boolean>])[],
  }
  interface RuntimeConfig {
   app: {
      baseURL: string,

      buildAssetsDir: string,

      cdnURL: string,
   },

   sitemap: {
      isI18nMapped: boolean,

      sitemapName: string,

      isMultiSitemap: boolean,

      excludeAppSources: Array<any>,

      cacheMaxAgeSeconds: number,

      autoLastmod: boolean,

      defaultSitemapsChunkSize: number,

      sortEntries: boolean,

      debug: boolean,

      discoverImages: boolean,

      isNuxtContentDocumentDriven: boolean,

      xsl: string,

      xslTips: boolean,

      xslColumns: Array<{

      }>,

      credits: boolean,

      version: string,

      sitemaps: {
         "sitemap.xml": {
            sitemapName: string,

            route: string,

            defaults: any,

            include: Array<any>,

            exclude: Array<string>,

            includeAppSources: boolean,
         },
      },
   },

   "nuxt-site-config": {
      stack: Array<{

      }>,

      version: string,

      debug: boolean,
   },

   "nuxt-simple-robots": {
      version: string,

      usingNuxtContent: boolean,

      debug: boolean,

      credits: boolean,

      groups: Array<{

      }>,

      sitemap: Array<string>,

      robotsEnabledValue: string,

      robotsDisabledValue: string,
   },
  }
  interface PublicRuntimeConfig {
   wsHost: string,

   apiBase: string,

   vueQuery: {
      stateKey: string,

      autoImports: Array<string>,

      queryClientOptions: {
         defaultOptions: {
            queries: {
               staleTime: number,
            },
         },
      },

      vueQueryPluginOptions: any,
   },

   i18n: {
      baseUrl: string,

      locales: {
         tg: {
            domain: any,
         },

         ru: {
            domain: any,
         },

         en: {
            domain: any,
         },
      },
   },

   "nuxt-schema-org": {
      reactive: boolean,

      minify: boolean,

      scriptAttributes: {
         id: string,
      },

      identity: any,

      version: string,
   },

   "nuxt-link-checker": {
      version: string,

      hasSitemapModule: boolean,

      rootDir: string,

      isNuxtContentDocumentDriven: boolean,

      excludeLinks: Array<any>,

      skipInspections: Array<any>,

      fetchTimeout: number,

      showLiveInspections: boolean,

      fetchRemoteUrls: boolean,
   },
  }
}
declare module 'vue' {
        interface ComponentCustomProperties {
          $config: RuntimeConfig
        }
      }