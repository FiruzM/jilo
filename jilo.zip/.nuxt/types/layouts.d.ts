import { ComputedRef, MaybeRef } from 'vue'
export type LayoutKey = "admin-dashboard" | "default"
declare module "../../node_modules/.pnpm/nuxt@3.9.1_@types+node@20.11.0_eslint@8.56.0_rollup@4.9.4_typescript@5.3.3_vite@5.0.11_vue-tsc@1.8.27/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: MaybeRef<LayoutKey | false> | ComputedRef<LayoutKey | false>
  }
}