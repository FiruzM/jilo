<script setup lang="ts">
definePageMeta({
  layout: 'admin-dashboard',
  title: 'Админка',
})
</script>

<template>
  <div>
    <h1>hello</h1>
  </div>
</template>
